class Badge < ApplicationRecord
  has_many :user_badges, dependent: :destroy
  has_many :users, through: :user_badges
  validates :name, presence: true, uniqueness: true
  validates :description, presence: true
end
